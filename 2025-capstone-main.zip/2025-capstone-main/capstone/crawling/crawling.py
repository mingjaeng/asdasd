import os
import xml.etree.ElementTree as ET
import requests
import json

API_KEY = "a8716de126a9dab75fd2facd6d634250b4b0b1d3"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CORPCODE_PATH = os.path.join(BASE_DIR, "corp_data", "CORPCODE.xml")

def get_corp_code(stock_code, corpcode_xml_path=CORPCODE_PATH):
    tree = ET.parse(corpcode_xml_path)
    root = tree.getroot()
    for child in root.findall("list"):
        if child.find("stock_code").text == stock_code:
            return child.find("corp_code").text
    raise ValueError(f"stock_code {stock_code}에 해당하는 corp_code가 없습니다.")

def fetch_financial_data(corp_code, bgn_de, reprt_code):
    url = "https://opendart.fss.or.kr/api/fnlttSinglAcnt.json"
    params = {
        "crtfc_key": API_KEY,
        "corp_code": corp_code,
        "bsns_year": bgn_de,
        "reprt_code": reprt_code,
        "fs_div": "CFS",  # 연결재무제표
        "api_type": "json",
    }
    response = requests.get(url, params=params)
    data = response.json()
    if data["status"] != "000":
        raise Exception(f"API 오류: {data.get('message', '')}")
    return data

def save_to_json(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def print_account_names(items):
    account_names = set()
    for item in items:
        account_nm = item.get("account_nm")
        if account_nm:
            account_names.add(account_nm)
    print("수집된 항목명 리스트:")
    for name in sorted(account_names):
        print("-", name)
    print(f"총 {len(account_names)}개 항목")

def main(stock_code):
    corp_code = get_corp_code(stock_code)
    years = ["2024", "2023", "2022"]
    reprt_code = "11011"  # 사업보고서(연간)

    fs_divisions = {
        "포괄손익계산서": "IS",
        "재무상태표": "BS"
    }

    for year in years:
        print(f"\n=== {year}년 {stock_code} 데이터 수집 시작 ===")
        data = fetch_financial_data(corp_code, year, reprt_code)
        full_items = data.get("list", [])

        for fs_name, sj_div_code in fs_divisions.items():
            filtered_items = [item for item in full_items if item.get("sj_div") == sj_div_code]

            filename = f"{stock_code}_{year}_{fs_name}.json"
            save_to_json(filtered_items, filename)
            print(f"{filename} 저장 완료.")

            print(f"\n{year}년 {fs_name} 항목명:")
            print_account_names(filtered_items)
            print("-" * 40)

if __name__ == "__main__":
    # 10개 기업 주식코드 리스트 (예: 실제 주식코드로 바꿔주세요)
    stock_codes = [
        "211270",  # AP위성
        "194480",  # 데브시스터즈
        "060480",  # 한선엔지니어링
        "002240",  # 고려제강
        "140410",  # 메카로
        "006800",  # 미래에셋증권
        "370030",  # 폴라리스AI
        "090710",  # 로보로보
        "108860",  # 셀바스헬스케어
        "017810",  # 성우하이텍
    ]

    for code in stock_codes:
        try:
            main(code)
        except Exception as e:
            print(f"{code} 처리 중 오류 발생: {e}")